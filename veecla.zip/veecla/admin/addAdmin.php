<?php 
require_once __DIR__. "/adminHeader.php";
?>

<?php 
require_once __DIR__. "/adminFooter.php";
?>