<?php 

define("HOST", "localhost");
define("USERNAME", "root");
define("PASSWORD", null);
define("DATABASE", "veecla");