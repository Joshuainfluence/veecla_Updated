<?php

require_once __DIR__ . "/adminHeader.php";
?>

<div class="container">
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card shadow">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-primary">Top 5 Ordered Products</h6>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
        <div class="col-lg-6 mb-4">
            <div class="card shadow">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-primary">Least 5 Ordered Products</h6>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
</div>

<?php 
require_once __DIR__. "/adminFooter.php";
?>